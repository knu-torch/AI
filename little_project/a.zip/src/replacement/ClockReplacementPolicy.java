package replacement;

// TODO: Import libraries if needed.

/**
 * Implements the CLOCK replacement policy.
 * This policy uses a circular buffer and reference bits to approximate LRU behavior.
 */
public class ClockReplacementPolicy implements ReplacementPolicy {
    // TODO: Add variables or functions as needed.

    /**
     * Constructs a ClockReplacementPolicy instance with the specified capacity.
     *
     * @param capacity The maximum number of pages the buffer pool can hold.
     */
    public ClockReplacementPolicy(int capacity) {
        // TODO: Implement this function.
    }

    /**
     * Initializes the Clock replacement policy.
     * Resets the internal state, clearing all pages and reference bits.
     */
    @Override
    public void init() {
        // TODO: Implement this function.
    }

    /**
     * Notifies the policy of a page access.
     * If the page is already in the buffer, sets its reference bit to true.
     * If not, adds the page to an empty slot in the buffer.
     *
     * @param offset The offset of the accessed page.
     */
    @Override
    public void notifyPageAccess(long offset) {
        // TODO: Implement this function.
    }

    /**
     * Notifies the policy of a page eviction.
     * Removes the evicted page from the buffer and clears its reference bit.
     *
     * @param offset The offset of the evicted page.
     */
    @Override
    public void notifyPageEvict(long offset) {
        // TODO: Implement this function.
    }

    /**
     * Chooses a victim page to evict based on the Clock policy.
     * Finds the first page with a reference bit of 0, resetting bits with value 1.
     *
     * @return The offset of the page to evict.
     */
    @Override
    public long chooseVictim() {
        // TODO: Implement this function.
        return 0;
    }

    /**
     * Returns the name of this replacement policy.
     *
     * @return "CLOCK" as the name of the policy.
     */
    @Override
    public String getName() {
        return "CLOCK";
    }
}